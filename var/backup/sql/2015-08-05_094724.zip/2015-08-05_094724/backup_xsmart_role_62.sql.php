<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_role`;
INSERT INTO `xsmart_role`(`id`,`listorder`,`updatetime`,`inputtime`,`title`,`style`) VALUES ("5","2","1429516348","1429516348","iOS开放",""),("6","2","1429517008","1429517008","网络营销开放",""),("7","0","1430794537","1430794537","全部开放",""),("8","0","1431423027","1431423027","大众会员","");
