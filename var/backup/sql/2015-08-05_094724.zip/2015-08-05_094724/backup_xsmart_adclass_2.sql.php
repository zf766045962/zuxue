<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_adclass`;
INSERT INTO `xsmart_adclass`(`classid`,`bid`,`parentid`,`classname`,`uunique`,`lmorder`,`classurl`,`readme`,`keyword`,`description`) VALUES ("1","1","0","首页-广告","","10","","","",""),("4","1","0","footer-二维码","","20","","","",""),("5","1","0","网站logo","","30","","","","");
