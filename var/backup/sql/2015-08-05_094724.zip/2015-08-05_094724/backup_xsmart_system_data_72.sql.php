<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_system_data`;
INSERT INTO `xsmart_system_data`(`id`) VALUES ("3"),("4"),("13"),("13"),("14"),("14"),("15"),("16"),("17"),("18"),("19"),("20"),("21"),("22"),("23"),("24"),("25"),("26"),("27"),("29"),("30"),("32"),("33");
