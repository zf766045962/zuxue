<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_couclass`;
INSERT INTO `xsmart_couclass`(`classid`,`bid`,`parentid`,`classname`,`uunique`,`lmorder`,`classurl`,`readme`,`keyword`,`description`) VALUES ("1","0","0","mooc课程","","1","","","",""),("2","0","0","商学院","","2","","","",""),("3","0","0","计算机学院","","3","","","",""),("4","0","0","土木工程","","4","","","",""),("5","0","0","艺术设计","","5","","","","");
