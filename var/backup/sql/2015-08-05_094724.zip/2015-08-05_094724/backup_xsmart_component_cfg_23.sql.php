<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_component_cfg`;
INSERT INTO `xsmart_component_cfg`(`component_id`,`cfgName`,`cfgValue`,`desc`) VALUES ("1","show_num","10","显示的记录条数");
