<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_page_prototype`;
INSERT INTO `xsmart_page_prototype`(`id`,`name`,`desc`,`type`,`components`,`url`) VALUES ("2","自定义页面","自定义页面原型","2","","custom"),("1","自定义页面","自定义页面原型","1","","custom");
