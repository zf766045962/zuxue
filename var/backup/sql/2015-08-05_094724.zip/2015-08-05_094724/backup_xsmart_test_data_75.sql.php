<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_test_data`;
INSERT INTO `xsmart_test_data`(`id`) VALUES ("1"),("2"),("3");
