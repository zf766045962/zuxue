<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_email_class`;
INSERT INTO `xsmart_email_class`(`classid`,`classname`,`sort`) VALUES ("1","默认地址分类","1"),("2","默认地址分类2","2");
