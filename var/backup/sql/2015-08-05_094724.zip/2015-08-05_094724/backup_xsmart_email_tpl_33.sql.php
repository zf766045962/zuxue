<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_email_tpl`;
INSERT INTO `xsmart_email_tpl`(`id`,`tplname`,`title`,`content`,`tpl_pic`) VALUES ("1","自定义模板1","北方互动科技有限公司开发EMD啦！！！","<p>付豪 是 傻子.<img src=\"http://img.baidu.com/hi/jx2/j_0002.gif\" /><br /></p>","/var/upload/pic/2015/05/20150521014015_64214.png"),("2","自定义模板2","测试邮件标题好木好.? ","<p>测试邮件内容好木好.?<br /></p>","/var/upload/pic/2015/05/20150521014054_81471.png"),("3","自定义模板3","22","<p>1222<br /></p>","/var/upload/pic/2015/05/20150521014127_48106.png");
