<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_courschool`;
INSERT INTO `xsmart_courschool`(`id`,`thumb`,`listorder`,`updatetime`,`inputtime`,`title`,`style`,`introduce`,`kc_hours`,`mv_url`,`preCourse`,`preCourse_idstr`,`teach_id`,`coreContent`,`audit`,`top`,`recommend`,`schoolid`,`classid`,`bid`) VALUES ("1","/var/upload/image/2015/05/20150513095047_66307.png","1","0","1431519300","课程名称","","","3小时25分","dsajfhsdakfkdsjfksdafjkas ","","","0","","1","0","0","28","3","0");
