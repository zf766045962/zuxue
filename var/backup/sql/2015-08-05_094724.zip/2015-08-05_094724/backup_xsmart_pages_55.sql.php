<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_pages`;
INSERT INTO `xsmart_pages`(`page_id`,`page_name`,`desc`,`native`,`url`,`prototype_id`,`type`,`params`) VALUES ("1","啊实打实","阿斯顿","0","custom","1","0",""),("2","首页","熬枯受淡","0","custom","1","0","");
