<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_user_status`;
INSERT INTO `xsmart_user_status`(`uid`,`regip`,`lastip`,`lastvisit`,`lastactivity`,`lastpost`,`lastsendmail`,`invisible`,`buyercredit`,`sellercredit`,`favtimes`,`sharetimes`,`profileprogress`) VALUES ("1","","127.0.0.1","1366768270","1366768270","1366768508","0","0","0","0","0","0","0");
