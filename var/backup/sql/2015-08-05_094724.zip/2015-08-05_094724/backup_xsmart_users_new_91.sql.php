<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_users_new`;
