<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_email_basic`;
INSERT INTO `xsmart_email_basic`(`id`,`admin_email`,`sender`,`tplid`) VALUES ("1","chenyining@vi163.com","北方互动科技","3");
