<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_email_address`;
INSERT INTO `xsmart_email_address`(`id`,`cid`,`address`,`is_ok`,`addtime`) VALUES ("9","1","admin@xuer.com","1","2015-05-21 09:44:28");
