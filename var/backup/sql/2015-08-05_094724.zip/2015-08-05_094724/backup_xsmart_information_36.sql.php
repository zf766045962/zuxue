<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_information`;
INSERT INTO `xsmart_information`(`id`,`content`,`addtime`,`status`) VALUES ("4","<p><span style=\"color: rgb(255, 0, 0);\">大家好</span><br></p>","1432110367","1"),("5","<p>登录既送<br></p>","1432894396","1");
