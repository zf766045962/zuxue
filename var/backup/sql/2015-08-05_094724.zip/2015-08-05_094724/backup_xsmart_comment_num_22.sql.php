<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_comment_num`;
INSERT INTO `xsmart_comment_num`(`id`,`good`,`bad`,`inputtime`,`updatetime`,`coid`) VALUES ("1","1","0","1432523090","1432523090","9"),("2","1","0","1432540221","1432540221","13"),("3","1","0","1432541371","1432541371","102"),("4","1","0","1432544344","1432544344","10");
