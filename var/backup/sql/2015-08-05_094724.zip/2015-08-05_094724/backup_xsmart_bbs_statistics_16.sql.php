<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_bbs_statistics`;
