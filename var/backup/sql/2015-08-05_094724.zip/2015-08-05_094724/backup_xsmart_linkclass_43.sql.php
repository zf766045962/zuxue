<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_linkclass`;
INSERT INTO `xsmart_linkclass`(`classid`,`bid`,`parentid`,`classname`,`uunique`,`lmorder`,`classurl`,`readme`,`keyword`,`description`) VALUES ("1","2","0","首页友链","","10","","","",""),("2","2","0","院校友链","universityLink","20","","","","");
