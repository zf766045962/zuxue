<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_email_smtp`;
INSERT INTO `xsmart_email_smtp`(`id`,`smtp`,`username`,`password`,`sort`,`is_ok`) VALUES ("2","smtp.qq.com","chenyining@vi163.com","a123123","1","1");
