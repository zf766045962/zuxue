<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_nav`;
INSERT INTO `xsmart_nav`(`id`,`name`,`parent_id`,`in_use`,`sort_num`,`page_id`,`is_blank`,`url`,`type`,`isNative`) VALUES ("1","新闻中心","0","1","1","1","0","","1","0"),("2","2323","0","1","0","0","0","","1","0"),("3","aaa","1","1","0","1","0","","1","0");
