<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_star_student_data`;
INSERT INTO `xsmart_star_student_data`(`id`) VALUES ("0"),("0"),("0"),("1"),("2"),("3"),("4"),("5"),("6"),("7"),("9"),("10"),("11"),("12"),("13"),("14");
