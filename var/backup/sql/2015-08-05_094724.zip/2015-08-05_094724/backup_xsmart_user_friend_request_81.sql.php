<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_user_friend_request`;
