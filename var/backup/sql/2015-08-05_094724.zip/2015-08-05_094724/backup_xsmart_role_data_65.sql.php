<?php exit("Access deny");?>
TRUNCATE TABLE `xsmart_role_data`;
INSERT INTO `xsmart_role_data`(`id`) VALUES ("1");
